/*!
 * Study Flow - Chrome Extension
 * Copyright (c) 2026 Study Flow. All rights reserved.
 * This code is proprietary and confidential.
 * Unauthorized copying, modification, or distribution is strictly prohibited.
 * License: Proprietary - Not for redistribution
 */
