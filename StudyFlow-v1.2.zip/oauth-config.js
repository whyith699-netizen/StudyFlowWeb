/*!
 * Study Flow - Chrome Extension
 * Copyright (c) 2026 Study Flow. All rights reserved.
 * This code is proprietary and confidential.
 * Unauthorized copying, modification, or distribution is strictly prohibited.
 * License: Proprietary - Not for redistribution
 */
(()=>{const o={clientId:"912149378367-m8f9dmbftn2ulu56fl4rk19csjnr5tpp.apps.googleusercontent.com",scopes:["email","profile"],authUrl:"https://accounts.google.com/o/oauth2/auth",tokenUrl:"https://oauth2.googleapis.com/token"};window.isOAuthConfigured=function(){return!(!o.clientId||"YOUR_CLIENT_ID_HERE.apps.googleusercontent.com"===o.clientId)||(console.warn("[OAUTH] Client ID not configured. Please update oauth-config.js"),!1)},window.getOAuthConfig=function(){return o}})();