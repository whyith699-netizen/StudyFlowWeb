/*!
 * Study Flow - Chrome Extension
 * Copyright (c) 2026 Study Flow. All rights reserved.
 * This code is proprietary and confidential.
 * Unauthorized copying, modification, or distribution is strictly prohibited.
 * License: Proprietary - Not for redistribution
 */
window.showConfirmModal=function(n,e,t,c="fa-exclamation-triangle"){const i=document.createElement("div");i.className="confirm-modal-overlay",i.innerHTML=`\n        <div class="confirm-modal">\n            <div class="confirm-modal-icon">\n                <i class="fas ${c}"></i>\n            </div>\n            <div class="confirm-modal-title">${n}</div>\n            <div class="confirm-modal-message">${e}</div>\n            <div class="confirm-modal-buttons">\n                <button class="btn btn-cancel">Cancel</button>\n                <button class="btn btn-confirm-delete">Confirm</button>\n            </div>\n        </div>\n    `,document.body.appendChild(i),i.querySelector(".btn-cancel").addEventListener("click",function(){i.remove()}),i.querySelector(".btn-confirm-delete").addEventListener("click",function(){i.remove(),t&&t()}),i.addEventListener("click",function(n){n.target===i&&i.remove()})};